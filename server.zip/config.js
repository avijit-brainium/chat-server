/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

var config = {
    port: process.env.PORT || 3000,
    database : 'mongodb://localhost:27017/avchat',
    secret: 'awsdfaaCSCDQ$421edascDAFDRWQ43214546asfA~@*34254DFASa'
};
module.exports = config;

